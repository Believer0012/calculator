var x ;
var symb;
var y;
var c;
function cler(){
    document.getElementById('ans').value=""; 
}
function num(a){
    document.getElementById('ans').value=document.getElementById('ans').value+a;
}


function sym(s){
    x=eval(document.getElementById('ans').value);
    document.getElementById('ans').value=s;
    symb=document.getElementById('ans').value;
    document.getElementById('ans').value="";

    
}
function squa()
{
        x=eval(document.getElementById('ans').value);
        let c=
        document.getElementById('ans').value=c ;
}
function bak()
{
    let str=document.getElementById("ans").value;
    let l=str.length-1;
    document.getElementById("ans").value = str.substr(0,l);
}


function equal()
{
    y=eval(document.getElementById('ans').value);
    
    if(symb=='+')
    {    
        c=x+y;
        document.getElementById('ans').value=c;
    }
    else if(symb=='-')
    {
        c=x-y;
        document.getElementById('ans').value=c;
    }
    else if(symb=='*')
    {
        c=x*y;
        document.getElementById('ans').value=c;
    } 
    else if(symb=='/')
    {
        c=x/y;
        document.getElementById('ans').value=c;
    } 

  
    
    
    

}

