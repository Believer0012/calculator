z=0
x=0
c=0
function cap()
{
    if(z==0){
        z=1;
    }else{
        z=0;
    }
}
function shift(){
    if(x==0){
        x=1;
    }
}
function typ(a){
    if((z==1)||(x==1)){
        let character=a.toUpperCase();
        document.getElementById("type").value+=character;
        x=0;
    
    }
    else{
        let character=a.toLowerCase();
        document.getElementById("type").value+=character;
    }
    
}
function back(){
    let str=document.getElementById("type").value;
    let l=str.length-1;
    document.getElementById("type").value = str.substr(0,l);
}
function enter(){
    document.getElementById("type").value+="\n";
}
function tab(){
    document.getElementById("type").value+="\t";
}
function space(){
    document.getElementById("type").value+=" ";
}
function numbers(q){
    
    if(c==1)
    {
        document.getElementById("type").value=document.getElementById('type').value+q;

    }

   }
   function sym(w){
       a= eval(document.getElementById("type").value);
       s=w;
       document.getElementById("type").value=" ";
      
   }
   function square()
   {
    answer=(a*a);
    document.getElementById("type").value=answer;
   }
   function arithmetic(){
       e=eval(document.getElementById("type").value);
       if (s=="+"){
           answer=a+e;
       }else if(s=="-"){
           answer=a-e;
       }else if(s=="*"){
           answer=a*e;
       }else if(s=="/"){
           answer=a/e;
       }else{
           answer="invalid operation"
       }
       document.getElementById("type").value=answer;

    }
function numslock(){

    
if(c==0){
    c=1
}else{
    c=0
}
}