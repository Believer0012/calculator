function selct(){
{ 
   if(document.getElementById('checkall').checked)
   {
    document.getElementById('check1').checked=true;
    document.getElementById('check2').checked=true;
    document.getElementById('check3').checked=true;
   }
   else
   {
    document.getElementById('check1').checked=false;
    document.getElementById('check2').checked=false;
    document.getElementById('check3').checked=false;
   }

}
}
function sumit(){
    let a=document.getElementById('name').value;
    let a1=document.getElementById('uname').value;
    let a2=document.getElementById('mail').value;
    let a3=document.getElementById('phno').value;
    let a4=document.getElementById('pass').value;
    let a5=document.getElementById('pass1').value;
    let a6=document.getElementById('que').value;
    let a7=document.getElementById('sel').value;
    let pat=/^[A-z]+$/;
    let pat1=/^[A-z 0-9]+$/
    let pat2=/^[\@\. A-z \-]+$/;
    let pat3=/^[0-9]+$/;
    let pat4=/^[\@\. A-z \-]+$/;
    let x=pat.test(a);
    let x1=pat1.test(a1);
    let x2=pat2.test(a2);
    let x3=pat3.test(a3);
    let x4=pat4.test(a4);

    if(a=='')
    {
        document.getElementById('demo').innerHTML='Enter name';
        return false;
    }
    else{
        if(x==false)
        {
            document.getElementById('demo').innerHTML='Enter in Format';
            return false;
        }
    }
    
    if(a1=='')
    {
        document.getElementById('demo1').innerHTML='Enter username';
        return false;
    }
    else
    {
        if(x1==false)
        {
            document.getElementById('demo1').innerHTML='Enter in Format';
            return false;
        }

    }
    if(a2=='')
    {
        document.getElementById('demo2').innerHTML='Enter email';
        return false;
    }
    else
    {
        if(x2==false)
        {
            document.getElementById('demo2').innerHTML='Enter in Format';
            return false;
        }

    }
    if(a3=='')
    {
        document.getElementById('demo3').innerHTML='Enter number';
        return false;
    }
    else
    {
        if(x3==false)
        {
            document.getElementById('demo3').innerHTML='Enter in Format';
            return false;
        }

    }
    if(a4=='')
    {
        document.getElementById('demo4').innerHTML='Enter Password';
        return false;
    }
    else
    {
        if(x4==false)
        {
            document.getElementById('demo4').innerHTML='Enter in Format';
            return false;
        }

    }
    if(a5=='')
    {
        document.getElementById('demo5').innerHTML='Renter Password';
        return false;
    }
    else
    {
        if(a4!=a5)
        {
            document.getElementById('demo5').innerHTML='Enter same password';
            return false;
        }

    }
    if(document.getElementById('radio1').checked || document.getElementById('radio2').checked )
    {

    }
    else{
        document.getElementById('demo6').innerHTML='Choose the Gender';
        return false;
    }

    if(document.getElementById('check1').checked || document.getElementById('check2').checked || document.getElementById('check3').checked)
    {

    }
    else{
        document.getElementById('demo7').innerHTML='Choose any Hobby';
        return false;
    }
    if(a7==(''||'ch'))
    {
        document.getElementById('demo9').innerHTML='Choose an option';
        return false;
    }
    if(a6=='')
    {
        document.getElementById('demo8').innerHTML='Enter any query';
        return false;
    }

    alert('Registration Sucessful')


    

  
}
